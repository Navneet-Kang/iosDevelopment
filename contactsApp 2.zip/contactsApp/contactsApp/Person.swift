//
//  Todo.swift
//  contactsApp
//
//  Created by user165323 on 8/25/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//

import UIKit

class Todo: NSObject {
    var name:String!
    var contact:String?
    var isFavorite:Bool?
    var isComplete:Bool = false
    var isFav:Bool = false
    
    
    init(name:String,contact:String) {
        self.name = name ;
        self.contact = contact ;
        
    }

}
