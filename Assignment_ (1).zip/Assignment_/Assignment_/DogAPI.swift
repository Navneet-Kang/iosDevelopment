//
//  DogAPI.swift
//  Assignment_
//
//  Created by "user164956" on "09/30/20".
//

import Foundation

struct DogData: Decodable {
    
    var message: [String:[String]]?
    var status: String?
}

class DogApi {
    
    let server_url = "https://dog.ceo/api/breeds/list/all"
    
    func getDogBreeds(completion: @escaping ((DogData?) -> Void)) {
        
        let url = URL(string: server_url)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let responseData = data else { return }
            
            //Serialize json response
            do {
                let data = try JSONDecoder().decode(DogData.self, from: responseData)
                
                //Print all dog breeds
                print("Response:\(data)")
                completion(data)
            }
            catch let error {
                print("Error message:\(error)")
                completion(nil)
            }
            
            
        }.resume()
    }
}
