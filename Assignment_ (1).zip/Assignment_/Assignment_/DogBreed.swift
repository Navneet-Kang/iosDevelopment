//
//  DogBreed.swift
//  Assignment_
//
//  Created by "user164956" on "09/30/20".
//

import Foundation

class DogBreed {
    
    var name:String?
    var remoteUrl: String?
    var subBreeds: [String]?
}
