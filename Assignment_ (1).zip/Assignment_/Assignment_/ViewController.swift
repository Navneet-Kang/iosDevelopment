//
//  ViewController.swift
//  Assignment_
//
//  Created by "user164956" on "09/30/20".
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    var dogBreeds = [DogBreed]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .black
        //Start point - fetch all dog breeds from server
        let apiObj = DogApi()
        apiObj.getDogBreeds { (data) in
            guard let parsedJson = data else { return }
            
            if let items = parsedJson.message {
                for item in items {
                    let breed = DogBreed()
                    breed.name = item.key
                    breed.subBreeds = item.value
                    self.dogBreeds.append(breed)
                }
                DispatchQueue.main.async {
                    self.sortBreedsInAscendingOrder()
                    self.navigationItem.title = "Breeds & Sub-Breeds"
                }
            }
        }
    }

    func sortBreedsInAscendingOrder() {
        dogBreeds.sort { $0.name?.caseInsensitiveCompare($1.name!) == .orderedAscending}
        self.tableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dogBreeds.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dogBreeds[section].subBreeds?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dogBreeds[section].name ?? ""
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let breed = dogBreeds[indexPath.section]
        cell.textLabel?.text = breed.subBreeds?[indexPath.row] ?? ""
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 54.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(123)
        self.performSegue(withIdentifier: "detailVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("prepare for segue called.")
        if segue.identifier == "detailVC" {
            let viewController:DetailViewController = segue.destination as! DetailViewController
            let row = tableView.indexPathForSelectedRow ?? IndexPath()
           
        }
    }
}

