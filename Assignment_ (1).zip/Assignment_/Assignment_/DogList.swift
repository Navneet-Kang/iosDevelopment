//
//  DogList.swift
//  Assignment_
//
//  Created by "user164956" on "09/30/20".
//

import Foundation

class DogList {
    
    let image_url = "https://images.dog.ceo//breeds//poodle-miniature//n02113712_459.jpg"
    
    func getARandomImageOfABreed(completion: @escaping ((Data?)-> Void)) {
       
        let url = URL(string: image_url)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let responseData = data else { return }
            completion(responseData)
            
        }.resume()
    }
}
