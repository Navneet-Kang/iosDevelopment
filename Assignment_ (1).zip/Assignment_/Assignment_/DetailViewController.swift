//
//  DetailViewController.swift
//  Assignment_
//
//  Created by "user164956" on "09/30/20".
//

import UIKit

class DetailViewController: UIViewController {
    
    var data: Data?
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
          
        if let img = data {
            self.imageView.image = UIImage(data: img)
        }
        else {
            // There are no images asscoiated with Dogs object in the api repsonse so using a random image .
            DogList().getARandomImageOfABreed { (data) in
                guard let img = data else { return }
                DispatchQueue.main.async {
                    self.imageView.image = UIImage(data: img)
                }
            }
        }
    }
    
}
