//
//  ViewController.swift
//  NavneetDatepicker
//
//  Created by user165323 on 11/22/20.
//  Copyright © 2020 cambrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var datePicker: UIDatePicker!
    
    var country = ["India","Australia","United Kingdom","South Africa"]
    var years = ["1986","2004","2000","1990"]
    var col1 = 0
    var col2 = 0
    
    @IBOutlet weak var pickerLabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //We can use self.datasource =self
        // self.delegate = self
        
        // Do any additional setup after loading the view.
        
    
    }
    
    
    //UIPickerViewDelegate Methods
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        if(component==0)
        {
         return country[row]
        }
        else
        {
            return years[row]
        }
        
    }
    
    @IBAction func dateAction(_ sender: Any) {
                let df = DateFormatter()
        df.dateFormat = "MM/dd/YYYY"
                let now = df.string(from: datePicker.date)
                pickerLabel.text = country[col1] + "   " +  years[col2] + " " + now
                
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        
        
        if(component == 0)
        {
            col1 = row
            
        }
        
        if(component == 1)
        {
            col2 = row
            
        }
        
        let df = DateFormatter()
df.dateFormat = " MM/dd/YYYY"
        let now = df.string(from: datePicker.date)
        pickerLabel.text = country[col1] + "   " +  years[col2] + " " + now
        
        
    }
    
    
    //UIPickerviewDatasource
    
        func numberOfComponents(in pickerView: UIPickerView) -> Int
        {
            return 2
            
        }
    
    
     func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
     {
             if (component == 0) {
            return country.count
        }
        else {
            return years.count
        }
        
    }
    
        


}

