//
//  FirstViewController.swift
//  DiceProjectApp
//
//  Created by user165323 on 10/27/20.
//  Copyright © 2020 gurdeepSingh. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBAction func empireClick(_ sender: Any) {
        self.performSegue(withIdentifier: "empireSection", sender: nil )
        
    }
    
    
    @IBAction func rebelClick(_ sender: Any) {
        //self.performSegue(withIdentifier: <#T##String#>, sender: <#T##Any?#>)
        
        self.performSegue(withIdentifier: "rebelSection", sender: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //self.performSegue(withIdentifier: <#T##String#>, sender: <#T##Any?#>)
        
    }


}

