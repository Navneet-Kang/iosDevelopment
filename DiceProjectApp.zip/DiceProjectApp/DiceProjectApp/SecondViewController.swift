//
//  SecondViewController.swift
//  DiceProjectApp
//
//  Created by user165323 on 10/27/20.
//  Copyright © 2020 gurdeepSingh. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var first: UIImageView!
    @IBOutlet weak var second: UIImageView!
    
    @IBOutlet weak var third: UIImageView!
    @IBOutlet weak var fourth: UIImageView!
    
    @IBOutlet weak var fifth: UIImageView!
    
    @IBOutlet weak var changeDice: UIImageView!
    var recentRoll = [Int]()
    var move = 0
    @IBAction func rollTheDice(_ sender: Any) {
        
       
        
        var images = [#imageLiteral(resourceName: "1") , #imageLiteral(resourceName: "2") , #imageLiteral(resourceName: "3") ,#imageLiteral(resourceName: "4") ,#imageLiteral(resourceName: "5") ,#imageLiteral(resourceName: "6") ]
        var randomNumber = Int.random(in: 0...5)
        changeDice.image = images[randomNumber]
        
        
        if recentRoll.count<5
        {
            recentRoll.append(randomNumber)
             print(recentRoll)
            
            switch(recentRoll.count)
            {
            case 1 :
                 first.image = images[recentRoll[0]]
                break
                                          
            case 2:
                second.image = images[recentRoll[1]]
                break
               
                
            case 3:
                third.image = images[recentRoll[2]]
                break
                                          
            case 4:
                fourth.image = images[recentRoll[3]]
                break
                                                      
            case 5:
                fifth.image = images[recentRoll[4]]
                break
                
          
            default:
                print("Something Wrong!")
                
            }
            
        }
        else
        {
            recentRoll[move] = randomNumber
            
            if(move<4)
            {
                 move+=1
                
            }
            else
            {
                move=0
               
            }
                          first.image = images[recentRoll[0]]
                           second.image = images[recentRoll[1]]

                           third.image = images[recentRoll[2]]

                           fourth.image = images[recentRoll[3]]

                           fifth.image = images[recentRoll[4]]

            print("HISTORY ::::: \(recentRoll)")
            
            
            
            
        }
        
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
    }
    
    


}

