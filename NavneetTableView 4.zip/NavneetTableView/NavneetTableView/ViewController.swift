//
//  ViewController.swift
//  NavneetTableView
//
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource, UIGestureRecognizerDelegate{
    var tap = -1
    var tableCell:CustomTableViewCell?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        //tableCell?.starImage?.image=UIImage(systemName: "star")
        
      
      cell.doubleTapped = {

        if( cell.starImage?.image == UIImage(systemName: "star"))
        {
            cell.starImage?.image=nil

            
        }
       else
        {
            
         cell.starImage?.image = UIImage(systemName: "star")
        }
        
        
        
                  tableView.reloadData()
      }
      
      cell.cellTapped = {
          self.performSegue(withIdentifier: "DetailVC", sender: self)
      }
        tableView.tableFooterView = UIView()
        
        //
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        //tableCell=cell
        print("Selected Row")
        
        //cell.starImage?.image = UIImage(named: "star.png")!
        //cell.starImage?.image=#imageLiteral(resourceName: "star")
        
        

}
    
     

    override func viewDidLoad() {
        super.viewDidLoad()
       
       
    }
    
}

