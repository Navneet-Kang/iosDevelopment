//
//  TableViewCell.swift
//  HardikCellTable
//  Copyright © 2020 hardik. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var starPhoto:UIImageView?
     var doubleCellTapped : (() -> ())?
      var singleCellTapped : (() -> ())?


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.contentView.isUserInteractionEnabled = true
        
        // Do any additional setup after loading the view.
                     let singleTap = UITapGestureRecognizer(target: self, action: #selector(singleTapped))
                     singleTap.numberOfTapsRequired = 1
                     self.addGestureRecognizer(singleTap)
                     
                     let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
                     doubleTap.numberOfTapsRequired = 2
                     self.addGestureRecognizer(doubleTap)
              
                     singleTap.require(toFail: doubleTap)
              // Initialization code
        
          

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    @objc func doubleTapped(){
        self.doubleCellTapped?()
    }
    
    @objc func singleTapped(){
        self.singleCellTapped?()
    }
    
    

}
