//
//  ViewController.swift
//  HardikCellTable
//


import UIKit

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      var cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        

        cell.doubleCellTapped = {
            
            if( cell.starPhoto?.image == UIImage(systemName: "red"))
               {
                   cell.starPhoto?.image=nil
                cell.starPhoto?.image=#imageLiteral(resourceName: "blueStar")

                   
               }
              else
               {
                   
                cell.starPhoto?.image = UIImage(systemName: "red")
                cell.starPhoto?.image=#imageLiteral(resourceName: "red")
               }
               
               
               
                         tableView.reloadData()
            
           
            print("Double Tapped")
           
        }
        
        
        cell.singleCellTapped = {
            self.performSegue(withIdentifier: "RandomScreen", sender: self)
            print("Single Tapped")
        }
        tableView.tableFooterView = UIView()

          
          //
          

        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

