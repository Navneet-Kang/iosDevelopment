//
//  ViewController.swift
//  Assignment2
//
//  Created by user165323 on 11/20/20.
//  Copyright © 2020 cambrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

