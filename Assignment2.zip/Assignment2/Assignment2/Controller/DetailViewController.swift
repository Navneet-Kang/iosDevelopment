//
//  DetailViewController.swift
//  Assignment 2
//
//  Created by Josh Cambrian on 2020-10-27.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var contactImage: UIImageView!
    
    @IBOutlet weak var contactName: UITextField!
    @IBOutlet weak var contactPhonenumber: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
