//
//  Contacts.swift
//  Assignment 2
//
//  Created by Josh Cambrian on 2020-10-27.
//

import Foundation

class Contacts{
    
    var allContacts = [Person]()
    
    func createContact(name: String, phoneNumber: Int){
        allContacts.append(Person(name: name, phoneNumber: phoneNumber))
    }
    
}
