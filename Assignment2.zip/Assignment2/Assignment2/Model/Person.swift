//
//  Person.swift
//  Assignment 2
//
//  Created by Josh Cambrian on 2020-10-27.
//

import Foundation
import UIKit

class Person{
    var name: String
    var phoneNumber: Int
    var isFavorite = false
    var image: UIImage?
    
    init(name: String, phoneNumber: Int){
        self.name = name
        self.phoneNumber = phoneNumber
    }
}
