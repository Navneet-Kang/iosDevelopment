//
//  TodoList.swift
//  contactsApp
//
//  Created by user165323 on 8/25/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//

import UIKit

class TodoList
{
    var list = [Todo]()
    
    init()
    {
        /*
        create(title: "Anna", desc: "437999679")
        create(title: "Bob", desc: "537999679")
        create(title: "Cinthie", desc: "737999679")
        create(title: "Denis", desc: "937999679")
        create(title: "Emiley", desc: "437999679")

        */
        
        
         var names = ["GGG","Anne","Bina","Cinthia","Denny","David","Dina","Deorge","Diffi","Dania","Darwin","Djack","Datherine","Douis","Danat","Davneet","Doprah","Deuja","Duataulian","Dachard","Diljeet","Damanat","Dunus","Dandana","Dusuf","Danthia","Disoza","Eric","Fina","George","Giffi","Hania","Irwin","Jack","Katherine","Louis","Manat","Navneet","Oprah","Pooja","Quataulian","Richard","Sania","Tania","Unus","Vandana","Wusuf","Xanthia","Yusuf","Zifi" ,"Irwin","Jack","Katherine","Louis","Manat","Navneet","Oprah","Pooja","Quataulian","Richard","Sania","Tania","Unus","Vandana","Wusuf","Xanthia","Yusuf","Zifi","Irwin","Jack","Katherine","Louis","Manat","Navneet","Oprah","Pooja","Quataulian","Richard","Sania","Tania","Unus","Vandana","Wusuf","Xanthia","Yusuf","Zifi"]
        
        
        let contacts=["9915694678","1815694678","2815694678","3815694678","4815694678","5815694678","6815694678","7815694678","8815694678","9815694678","1015694678","115694678","1215694678","1315694678","1415694678","1515694678",
        "1615694678","1715694678","1815694678","1915694678","2015694678","2115694678","2215694678","2315694678","2415694678","2515694678","2615694678","2715694678","2815694678","2915694678","3015694678","3115694678",
        "3215694678","3315694678","3415694678","3515694678","3615694678","3715694678","3815694678","3915694678","4015694678","4115694678","4215694678","4315694678","4415694678","4515694678","4615694678","4715694678",
        "4815694678","4915694678","5015694678","5115694678","5215694678","5315694678","5415694678","5515694678","5615694678","5715694678","5815694678","5915694678","6015694678","615694678","6215694678","6315694678"
            
                ]
        
/*
         names.sort()
         
         names.sort{
    $0.name < $1.name
}
 
 */
                var randIndex:Int
                
                for _ in 0...49
                {
                    randIndex=Int.random(in: 0...60)
                    create(name:names[randIndex],contact:contacts[randIndex])
                }
                
        

        
        
        
    }
    
    @discardableResult func create(name:String , contact:String)->Todo
    {
     let newTodo = Todo(name: name, contact: contact)
        list.append(newTodo)
        return newTodo
    }
    
    
    func removeTodo(_ todo : Todo)
    {
        //check if todo exist
        
        if let index = list.firstIndex(of: todo)
        {
            //remove the todo
            list.remove(at:index)
        }
    }
    
    
    func moveTodo(from fromIndex:Int, to toIndex:Int)
    {
        //store the person at from index in a temp variable
        let tmp=list[fromIndex]
        //remove the person
        list.remove(at: fromIndex)
        
        //Insert Todo List
        list.insert(tmp, at: toIndex)
        
    }
    
    
}
