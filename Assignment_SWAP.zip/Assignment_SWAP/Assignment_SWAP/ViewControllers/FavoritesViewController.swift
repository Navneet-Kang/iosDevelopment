//
//  FavoritesViewController.swift
//  Assignment_SWAP
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.

import UIKit

struct Favrt {
    
    let name: String
    let category: String
    
}

class FavoritesViewController: UIViewController , UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    
    var favrtData = [Favrt]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        tableView.backgroundColor = .white
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
    
        // Do any additional setup after loading the view.
      
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        favrtData.removeAll()
        if let data = CoreDataRepo.sharedDataInstance.fetchData() {
            for item in data {
                let favrt = Favrt(name: item.name!, category: item.category!)
                favrtData.append(favrt)
            }
            tableView.reloadData()
        }
    }
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favrtData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = favrtData[indexPath.row].name
        cell.detailTextLabel?.text = "Category :  \(favrtData[indexPath.row].category)"
        cell.backgroundColor = .white
        cell.textLabel?.textColor = .black
        return cell
    }
    
}
