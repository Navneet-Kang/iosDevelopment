//
//  DetailViewController.swift
//  Assignment_SWAP
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.
import UIKit

class DetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var films:[String]?
    var species: [String]?
    var vehicles: [String]?
    var starShips: [String]?
    var filmsArray = [Film]()
    var speciesArray = [Specie]()
    var vehiclesArray = [Vehicle]()
    var starShipsArray = [StarShip]()
   
    var names = [String?]()
    
    lazy var actvityIndicator : UIActivityIndicatorView = {
        let activity = UIActivityIndicatorView()
        activity.center = view.center
        activity.color = UIColor.darkGray
        activity.hidesWhenStopped = true
        activity.style = .large
        return activity
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        tableView.backgroundColor = .white
        view.addSubview(actvityIndicator)
        tableView.delegate = self
        tableView.dataSource = self
        //self.tableView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "CustomTableViewCell")
        loadData()
        tableView.tableFooterView = UIView()
    }
    
    private func loadData() {
        if films != nil {
            fetchFilms()
        }
        
        else if species != nil{
            fetchSpecies()
        }
        
        else if vehicles != nil {
            fetchVehicles()
        }
        
        else if starShips != nil{
            fetchStarShips()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
        
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = names[indexPath.row]
        cell.selectionStyle = .none
        cell.backgroundColor = .white
        cell.textLabel?.textColor = .black
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(identifier: "SubDetailsViewController") as! SubDetailsViewController
        if filmsArray.count > 0 {
            vc.film = filmsArray[indexPath.row]
        }
        
        else if speciesArray.count > 0 {
            vc.specie = speciesArray[indexPath.row]
        }
        
        else if vehiclesArray.count > 0 {
            vc.vehicle = vehiclesArray[indexPath.row]
        }
        
        else if starShipsArray.count > 0 {
            vc.starShip = starShipsArray[indexPath.row]
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func fetchFilms() {
        for item in films! {
            actvityIndicator.startAnimating()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                let request = URLRequest(url: URL(string: item)!)
                let task = self.getSession().dataTask(with: request, completionHandler: { data, response, error -> Void in
                    if let res = data {
                        do {
                            let res = try JSONDecoder().decode(Film.self, from: res)
                            self.names.append(res.title)
                            self.filmsArray.append(res)
                            self.updateUI()
                        } catch {
                            print("error")
                        }
                    }
                    else {
                        print(error?.localizedDescription)
                    }
                })
                task.resume()
            }
        }
    }
    
    private func fetchSpecies() {
        for item in species! {
            actvityIndicator.startAnimating()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                let request = URLRequest(url: URL(string: item)!)
                let task = self.getSession().dataTask(with: request, completionHandler: { data, response, error -> Void in
                    if let res = data {
                        do {
                            let res = try JSONDecoder().decode(Specie.self, from: res)
                            self.names.append(res.name)
                            self.speciesArray.append(res)
                            self.updateUI()
                        } catch {
                            print("error")
                        }
                    }
                    else {
                        print(error?.localizedDescription)
                        self.updateUI()
                    }
                })
                task.resume()
            }
        }
    }
    
    private func fetchVehicles() {
        for item in vehicles! {
            actvityIndicator.startAnimating()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                let request = URLRequest(url: URL(string: item)!)
                let task = self.getSession().dataTask(with: request, completionHandler: { data, response, error -> Void in
                    if let res = data {
                        do {
                            let res = try JSONDecoder().decode(Vehicle.self, from: res)
                            self.names.append(res.name)
                            self.vehiclesArray.append(res)
                            self.updateUI()
                        } catch {
                            print("error")
                        }
                    }
                    else {
                        print(error?.localizedDescription)
                    }
                })
                task.resume()
            }
        }
    }
    
    private func fetchStarShips() {
        for item in starShips! {
            actvityIndicator.startAnimating()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                let request = URLRequest(url: URL(string: item)!)
                let task = self.getSession().dataTask(with: request, completionHandler: { data, response, error -> Void in
                    if let res = data {
                        do {
                            let res = try JSONDecoder().decode(StarShip.self, from: res)
                            self.names.append(res.name)
                            self.starShipsArray.append(res)
                            self.updateUI()
                        } catch {
                            print("error")
                        }
                    }
                    else {
                        print(error?.localizedDescription)
                    }
                })
                task.resume()
            }
        }
    }
    
    
    private func getSession() -> URLSession {
        let session = URLSession.shared
        return session
    }
    
    private func updateUI() {
        DispatchQueue.main.async {
            self.actvityIndicator.stopAnimating()
            self.tableView.reloadData()
        }
    }
}


struct Film: Codable {
    let title: String
    let episodeID: Int
    let openingCrawl, director, producer, releaseDate: String
    let characters, planets, starships, vehicles: [String]
    let species: [String]
    let created, edited: String
    let url: String

    enum CodingKeys: String, CodingKey {
        case title
        case episodeID = "episode_id"
        case openingCrawl = "opening_crawl"
        case director, producer
        case releaseDate = "release_date"
        case characters, planets, starships, vehicles, species, created, edited, url
    }
}


struct Specie: Codable {
    let name, classification, designation, averageHeight: String
    let skinColors, hairColors, eyeColors, averageLifespan: String
    let homeworld: String
    let language: String
    let people, films: [String]
    let created: String
    let edited: String
    let url: String

    enum CodingKeys: String, CodingKey {
        case name, classification, designation
        case averageHeight = "average_height"
        case skinColors = "skin_colors"
        case hairColors = "hair_colors"
        case eyeColors = "eye_colors"
        case averageLifespan = "average_lifespan"
        case homeworld, language, people, films, created, edited, url
    }
}

struct Vehicle: Codable {
    let name, model, manufacturer, costInCredits: String
    let length, maxAtmospheringSpeed, crew, passengers: String
    let cargoCapacity, consumables, vehicleClass: String
    let pilots, films: [String]
    let created: String
    let edited: String
    let url: String

    enum CodingKeys: String, CodingKey {
        case name, model, manufacturer
        case costInCredits = "cost_in_credits"
        case length
        case maxAtmospheringSpeed = "max_atmosphering_speed"
        case crew, passengers
        case cargoCapacity = "cargo_capacity"
        case consumables
        case vehicleClass = "vehicle_class"
        case pilots, films, created, edited, url
    }
}


struct StarShip: Codable {
    let name, model, manufacturer, costInCredits: String
    let length, maxAtmospheringSpeed, crew, passengers: String
    let cargoCapacity, consumables, hyperdriveRating, mglt: String
    let starshipClass: String
    let pilots, films: [String]
    let created, edited: String
    let url: String

    enum CodingKeys: String, CodingKey {
        case name, model, manufacturer
        case costInCredits = "cost_in_credits"
        case length
        case maxAtmospheringSpeed = "max_atmosphering_speed"
        case crew, passengers
        case cargoCapacity = "cargo_capacity"
        case consumables
        case hyperdriveRating = "hyperdrive_rating"
        case mglt = "MGLT"
        case starshipClass = "starship_class"
        case pilots, films, created, edited, url
    }
}
