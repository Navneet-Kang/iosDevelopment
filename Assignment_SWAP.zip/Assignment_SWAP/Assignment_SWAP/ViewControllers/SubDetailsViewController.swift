//
//  SubDetailsViewController.swift
//  Assignment_SWAP
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.
import UIKit

struct DataSource  {
    let section: String
    let rows: [String]
}

class SubDetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var film: Film?
    var specie: Specie?
    var starShip: StarShip?
    var vehicle: Vehicle?

    var dataSource = [DataSource]()
    var imageIndexPath: IndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        tableView.backgroundColor = .white
        tableView.delegate = self
        tableView.dataSource = self
        self.tableView.register(UINib(nibName: "CustomTableViewCell", bundle: nil), forCellReuseIdentifier: "CustomTableViewCell")
        tableView.tableFooterView = UIView()
        loadSectionAndRows()
    }

    
    private func loadSectionAndRows() {
        if let filmObject = film {
            if filmObject.characters.count > 0 {
                var array = [String]()
                array.append(filmObject.title)
                array.append(filmObject.director)
                array.append(contentsOf: filmObject.characters)
                dataSource.append(DataSource(section: "Characters", rows: array))
            }
            if filmObject.planets.count > 0 {
                var array = [String]()
                array.append(filmObject.planets[0].description)
                array.append(contentsOf: filmObject.planets)
                dataSource.append(DataSource(section: "Planets", rows: array))
            }
            if filmObject.starships.count > 0 {
                var array = [String]()
                array.append(filmObject.starships[0].description)
                array.append(filmObject.director)
                array.append(contentsOf: filmObject.starships)
                dataSource.append(DataSource(section: "StarShips", rows: array))
                
            }
            if filmObject.vehicles.count > 0 {
                var array = [String]()
                array.append(filmObject.title)
                array.append(filmObject.director)
                array.append(contentsOf: filmObject.vehicles)
                dataSource.append(DataSource(section: "Vehicles", rows: array))
            }
            if filmObject.species.count > 0 {
                var array = [String]()
                array.append(filmObject.title)
                array.append(filmObject.director)
                array.append(contentsOf: filmObject.species)
                dataSource.append(DataSource(section: "Species", rows: array))
            }
        }
        
        if let specieObject = specie {
            if specieObject.people.count > 0 {
                var array = [String]()
                array.append(specieObject.name)
                array.append(specieObject.classification)
                array.append(contentsOf: specieObject.people)
                dataSource.append(DataSource(section: "Species", rows: array))
            }
            if specieObject.films.count > 0 {
                var array = [String]()
                array.append(specieObject.name)
                array.append(specieObject.classification)
                array.append(contentsOf: specieObject.films)
                dataSource.append(DataSource(section: "Films", rows: array))
            }
        }
        
        if let starShipObject = starShip {
            if starShipObject.films.count > 0 {
                var array = [String]()
                array.append(starShipObject.name)
                array.append(starShipObject.manufacturer)
                array.append(contentsOf: starShipObject.films)
                dataSource.append(DataSource(section: "Films", rows: array))
            }
            if starShipObject.pilots.count > 0 {
                var array = [String]()
                array.append(starShipObject.name)
                array.append(starShipObject.manufacturer)
                array.append(contentsOf: starShipObject.pilots)
                dataSource.append(DataSource(section: "Pilots", rows: array))
            }
        }
        
        if let vehicleObject = vehicle {
            if vehicleObject.films.count > 0 {
                var array = [String]()
                array.append(vehicleObject.name)
                array.append(vehicleObject.manufacturer)
                array.append(contentsOf: vehicleObject.pilots)
                dataSource.append(DataSource(section: "Films", rows: array))
            }
            if vehicleObject.pilots.count > 0 {
                var array = [String]()
                array.append(vehicleObject.name)
                array.append(vehicleObject.manufacturer)
                array.append(contentsOf: vehicleObject.pilots)
                dataSource.append(DataSource(section: "Pilots", rows: array))
            }
        }
        tableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource[section].rows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as! CustomTableViewCell
        
        let data = dataSource[indexPath.section]
        cell.label.text = data.rows[indexPath.row]
        cell.backgroundColor = .white
        cell.label.textColor = .black
        cell.selectionStyle = .none
        
        if imageIndexPath != nil  && imageIndexPath == indexPath {
            cell.imagee.image = UIImage(named: "like")
        }
        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dataSource[section].section
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 48.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as? CustomTableViewCell
        cell?.imagee.image = UIImage(named:"like")
        imageIndexPath = indexPath
        let favrt = Favrt(name: (cell?.label.text)!, category: dataSource[indexPath.section].section)
        CoreDataRepo.sharedDataInstance.saveData(favrt)
    }
    
}
