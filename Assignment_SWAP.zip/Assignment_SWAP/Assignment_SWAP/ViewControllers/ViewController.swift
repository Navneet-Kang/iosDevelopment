//
//  ViewController.swift
//  Assignment_SWAP
//
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.

import UIKit

class ViewController: UIViewController {

    var films:[String]?
    var species: [String]?
    var vehicles: [String]?
    var starShips: [String]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fecthData()
        
    }

    
    @IBAction func filmsAction(_ sender: Any) {
        let vc = getVC()
        vc.films = films
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func speciesAction(_ sender: Any) {
        let vc = getVC()
        vc.species = species
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func starshipsAction(_ sender: Any) {
        let vc = getVC()
        vc.starShips = starShips
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func vehiclesAction(_ sender: Any) {
        let vc = getVC()
        vc.vehicles = vehicles
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func fecthData() {
        let url = "https://swapi.dev/api/people/1"
        let request = URLRequest(url: URL(string: url)!)
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                if let response = data {
                let res = try JSONDecoder().decode(RootObject.self, from: response)
                    print(res)
                    self.films = res.films
                    self.species = res.species
                    self.starShips = res.starships
                    self.vehicles = res.vehicles
                }
            } catch {
                print("error")
            }
        })

        task.resume()
    }
    
    private func getVC() -> DetailViewController {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(identifier: "DetailViewController") as! DetailViewController
        return vc
    }
}



struct RootObject: Codable {
    let name: String
    let height: String
    let mass: String
    let hair_color: String
    let skin_color: String
    let eye_color: String
    let birth_year: String
    let gender: String
    let homeworld: String
    let films: [String]
    let species: [String]
    let vehicles: [String]
    let starships: [String]
    let created: String
    let edited: String
    let url: String
    
}
