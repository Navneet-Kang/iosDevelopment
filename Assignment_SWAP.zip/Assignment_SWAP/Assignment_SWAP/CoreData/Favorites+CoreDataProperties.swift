//
//  Favorites+CoreDataProperties.swift
//  Assignment_SWAP
//
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.
import Foundation
import CoreData


extension Favorites {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Favorites> {
        return NSFetchRequest<Favorites>(entityName: "Favorites")
    }

    @NSManaged public var name: String?
    @NSManaged public var category: String?

}

extension Favorites : Identifiable {

}
