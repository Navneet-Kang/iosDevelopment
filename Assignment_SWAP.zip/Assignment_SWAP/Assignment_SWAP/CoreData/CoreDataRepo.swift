//
//  CoreDataRepo.swift
//  Assignment_SWAP
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.

import Foundation
import CoreData

class CoreDataRepo {
    
    static let kDBmodelName = "Assignment_SWAP" // mention xcdatamodeld
    public static let sharedDataInstance: CoreDataRepo = CoreDataRepo(withModelName: kDBmodelName)
    
    private let modelName: String
    
    lazy var managedContext: NSManagedObjectContext = {
        return self.storeContainer.viewContext
    }()
    
    init(withModelName modelName: String) {
        self.modelName = modelName
    }
    
    private lazy var storeContainer:NSPersistentContainer = {
        let container = NSPersistentContainer(name: self.modelName)
        container.loadPersistentStores { (storeDiscription, error) in
            if let error = error as NSError? {
                print("Unresolved error \(error), \(error.userInfo)") }
        }
        return container
    }()
    
    func saveContext () {
        guard managedContext.hasChanges else { return }
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Unresolved error \(error), \(error.userInfo)") }
    }
    
    func fetchData() -> [Favorites]? {
        var objects: [Favorites]?
        let fetchRequest: NSFetchRequest<Favorites> = Favorites.fetchRequest()
        do {
            let managedContext: NSManagedObjectContext = CoreDataRepo.sharedDataInstance.managedContext
            objects = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }
        return objects
    }
    
    func saveData(_ object : Favrt) {
        let managedContext: NSManagedObjectContext = CoreDataRepo.sharedDataInstance.managedContext
        
        let favorite = Favorites(context: managedContext)
        favorite.name = object.name
        favorite.category = object.category
    
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Fetch error: \(error) description: \(error.userInfo)")
        }
    }

}
