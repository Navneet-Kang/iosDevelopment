//
//  Favorites+CoreDataClass.swift
//  Assignment_SWAP
//  Created by user165323 on 12/10/20.
//  Copyright © 2020 navneet. All rights reserved.

import Foundation
import CoreData

@objc(Favorites)
public class Favorites: NSManagedObject {

}
